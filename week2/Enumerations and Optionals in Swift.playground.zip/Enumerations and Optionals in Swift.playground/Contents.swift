// 1.
enum Gasoline {
    case oil92(rawValue: String = "92")
    case oil95(rawValue: String = "95")
    case oil98(rawValue: String = "98")

    func getPrice() -> String {
        switch self {
        case .oil92:
            return "TWD 28"
        case .oil95:
            return "TWD 30"
        case .oil98:
            return "TWD 32"
        }
     }
}


// 2.
class Pet {
    var name: String?
    
    init(name: String) {
        self.name = name
    }
}

class People {
    var pet: Pet?
    
    func keepPet() -> Bool {
        guard let _pet = pet else { return false }
        return true
    }
}

class People1 {
    var pet: Pet?
    
    func keepPet() -> Bool {
        if let _pet = pet { return true }
        return false
    }
}
